﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Carrello
{
    public partial class Aggiungi : Form
    {
        Form1 f;
        public Aggiungi(Form1 form)
        {
            InitializeComponent();
            List<string> prod = new List<string>();
            Leggi(prod);
            comboBox1.Items.AddRange(prod.ToArray());
            f = form; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.SelectedItem != null)
            {
                f.Aggiungi(new Prodotto(comboBox1.SelectedItem.ToString(), int.Parse(numericUpDown1.Value.ToString())));
                f.istanze = 0;
                Close();
            }
            else
            {
                MessageBox.Show("Completare tutti i campi correttamente!");
            }
            
        }

        private void Aggiungi_FormClosed(object sender, FormClosedEventArgs e)
        {
            f.istanze = 0;
        }
        private void Leggi(List<string> pr)
        {
            using (StreamReader sr = new StreamReader("../../ElencoProdotti.txt"))
            {
                string riga;
                while ((riga = sr.ReadLine()) != null)
                {
                    pr.Add(riga.Split('|')[0]);
                }
            }
        }
    }
}
