﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace Carrello
{
    public partial class Form1 : Form
    {
        public List<Prodotto> prods;
        public int istanze = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            prods = new List<Prodotto>() { };
            reload();
        }

        public void reload()
        {
            listView1.Items.Clear();
            ListViewItem item;
            double totale = 0.00F;
            foreach (Prodotto prod in prods)
            {
                item = new ListViewItem($"{prod.Id}: {prod.Nome} {prod.Prezzo:n2}$ x{prod.Quantita}",prod.Categoria);
                item.SubItems.Add(prod.Id);
                item.SubItems.Add(prod.Quantita.ToString());
                item.SubItems.Add(prod.Prezzo.ToString());
                listView1.Items.Add(item);
                totale += prod.Prezzo*prod.Quantita;
            }
            labelTot.Text = $"Totale: {totale:n2}$";
            if(listView1.Items.Count > 0)
            {
                button2.Enabled = true;
                label2.Visible = false;
            }
            else
            {
                button2.Enabled = false;
                label2.Visible = true;
            }
        }

        private void listView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                DialogResult dialogResult = MessageBox.Show("Sei sicuro di voler eliminare l'elemento selezionato dal tuo carello?", "Conferma", MessageBoxButtons.YesNo);
                if(dialogResult == DialogResult.Yes)
                {
                    prods.RemoveAt(listView1.SelectedIndices[0]);
                    reload();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(istanze < 1)
            {
                Aggiungi agg = new Aggiungi(this);
                agg.Show();
                istanze++;
            }
        }

        public void Aggiungi(Prodotto p)
        {
            int ind = -1;
            if (p.Quantita != 0)
            {
                for (int i = 0; i < prods.Count; i++)
                {
                    if (prods[i].Nome == p.Nome)
                    {
                        ind = i;
                        break;
                    }
                }
                if (ind != -1)
                {
                    if(prods[ind].Quantita + p.Quantita <= 100)
                    {
                        prods[ind].Quantita += p.Quantita;
                        MessageBox.Show("Quantità massima raggiunta per questo prodotto!");
                    }
                    
                }
                else
                {
                    prods.Add(p);
                }
                reload();
            }
        }

        private List<string> scontrinoBase()
        {
            List<string> list = new List<string>();
            foreach(string line in File.ReadAllLines("../../Scontrino.txt"))
            {
                list.Add(line);
            }
            return list;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Il pagamento effettuato, controlla il Desktop per la ricevuta");
            List<string> lines = scontrinoBase();
            string prezzo;
            lines[5] = $"Data:               {DateTime.Now.ToShortDateString()}";
            for(int i = 0; i < prods.Count; i++)
            {
                prezzo = prods[i].Prezzo.ToString("0.00");
                lines.Add($"{prods[i].Quantita,-6}{prods[i].Nome,-23}{prezzo}$");
            }
            lines.Add("");
            lines.Add("----------------------------------------");
            lines.Add("");
            lines.Add($"Totale:                      {labelTot.Text.Substring(8)}");
            lines.Add("");
            lines.Add("----------------------------------------");
            using (StreamWriter sw = new StreamWriter($"{Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)}/Desktop/Scontrino.txt"))
            {
                foreach (string line in lines)
                {
                    sw.WriteLine(line);
                }
            }
            prods.Clear();
            reload();
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.ForeColor = Color.FromArgb(73, 191, 118);
            button2.FlatAppearance.BorderSize = 1;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.ForeColor = Color.White;
            button2.FlatAppearance.BorderSize = 0;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if(istanze < 1)
            {
                Aggiungi agg = new Aggiungi(this);
                agg.Show();
                istanze++;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                prods[listView1.SelectedIndices[0]].Quantita = (int)numericUpDown1.Value;
                reload();
                numericUpDown1.Visible = false;
                button3.Visible = false;
            }

        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                if (listView1.SelectedItems.Count > 0)
                {
                    numericUpDown1.Value = prods[listView1.SelectedItems[0].Index].Quantita;
                    numericUpDown1.Visible = true;
                    button3.Visible = true;
                }
            }
        }
    }
}
