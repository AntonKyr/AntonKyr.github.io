﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Carrello
{
    public class Prodotto
    {
        #region Attributi
        string id = "";
        string nome;
        int categoria;
        int quantita;
        float prezzo;
        static List<float> prezzi = new List<float>();
        static  List<string> prod = new List<string>();
        
        #endregion

        #region Costruttori
        public Prodotto(string nome, int quantita)
        {
            Nome = nome;
            Quantita = quantita;
            setId();
            setCategoria();
        }
        #endregion

        #region Property
        public string Nome { 
            get => nome; 
            set
            {
                Leggi();
                if (value.Length < 3 && value.Length > 250)
                {
                    throw new Exception("Il valore inserito nel campo nome non è valido");
                }
                else
                {
                    for(int i = 0; i < prod.Count; i++)
                    {
                        if(value.ToLower() == prod[i].ToLower()) 
                        {
                            nome = value;
                            setPrezzo(i);
                            break;
                        }
                    }
                }
            }
        }
        public int Quantita
        {
            get => quantita;
            set
            {
                if (value < 1 && value > 99)
                {
                    throw new Exception("Il valore inserito nel campo quantità non è valido");
                }
                quantita = value;
            }
        }

        public int Categoria { 
            get => categoria;
        }
        public string Id { get => id; }
        public float Prezzo { get => prezzo; }

        private void setCategoria()
        {
            for (int i = 0; i < prod.Count; i++)
            {
                if (Nome.ToLower() == prod[i].ToLower() && i < 6)
                {
                    categoria = 0;
                    break;
                }
                else if (Nome.ToLower() == prod[i].ToLower() && i < 8)
                {
                    categoria = 2;
                    break;
                }
                else
                {
                    categoria = 1;
                }
            }
        }

        private void setPrezzo(int id)
        {
            prezzo = prezzi[id];
        }

        private void setId()
        {
            id = $"{this.Nome.Substring(0, 3)}001";
        }
        #endregion

        public override string ToString()
        {
            return $"Nome: {Nome} - Quantita: {Quantita} - Prezzo: {Prezzo}";
        }

        private void Leggi()
        {
            using(StreamReader sr = new StreamReader("../../ElencoProdotti.txt"))
            {
                string riga;
                while((riga = sr.ReadLine()) != null)
                {
                    prod.Add(riga.Split('|')[0]);
                    float f = float.Parse(riga.Split('|')[1]);
                    prezzi.Add(f);
                }
            }
        }
    }
}
